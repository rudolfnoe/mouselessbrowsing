function MLB_onDiaglogAccept(){
	window.arguments[0].out = document.getElementById('styleresetRG').value
}