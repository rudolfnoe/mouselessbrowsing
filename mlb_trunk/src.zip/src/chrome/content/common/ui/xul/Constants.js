with(this){
/*
 * 
 */
(function(){
	//Common Constants
	var Constants = {
		VERSION: "0.2",
		XUL_NS: "http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul",
		HTML_NS: "http://www.w3.org/1999/xhtml"
	}
	this["Constants"]= Constants;
}).apply(this)
	
}